/* CryptoNova Landing JS */
(function() {
  const cfg = window.CRYPTONOVA_CFG || {};
  const projectWallet = cfg.projectWallet || "";
  const tokenAddress = cfg.tokenAddress || "";
  const icoDate = cfg.icoDate ? new Date(cfg.icoDate) : null;

  // Canvas stars background
  const canvas = document.getElementById('bg');
  const ctx = canvas.getContext('2d');
  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();
  let stars = [];
  for(let i=0; i<150; i++) {
    stars.push({
      x: Math.random()*canvas.width,
      y: Math.random()*canvas.height,
      radius: Math.random()*1.5,
      dx: (Math.random()-0.5)*0.4,
      dy: (Math.random()-0.5)*0.4
    });
  }
  function animate() {
    ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.fillStyle = "#fff";
    stars.forEach(s => {
      ctx.beginPath();
      ctx.arc(s.x,s.y,s.radius,0,2*Math.PI);
      ctx.fill();
      s.x += s.dx;
      s.y += s.dy;
      if(s.x<0 || s.x>canvas.width) s.dx *= -1;
      if(s.y<0 || s.y>canvas.height) s.dy *= -1;
    });
    requestAnimationFrame(animate);
  }
  animate();

  // Scroll fade-in
  const sections = document.querySelectorAll('section');
  function checkVisible() {
    sections.forEach(s=>{
      const top = s.getBoundingClientRect().top;
      if(top < window.innerHeight - 100) s.classList.add('visible');
    });
  }
  window.addEventListener('scroll', checkVisible);
  checkVisible();

  // Timer ICO
  const timerEl = document.getElementById('timer');
  function updateTimer() {
    if(!icoDate) {
      timerEl.textContent = "Скоро ICO";
      return;
    }
    let now = new Date();
    let diff = icoDate - now;
    if(diff <= 0) {
      timerEl.textContent = "ICO стартовало!";
      return;
    }
    let days = Math.floor(diff/(1000*60*60*24));
    let hours = Math.floor((diff/(1000*60*60))%24);
    let mins = Math.floor((diff/(1000*60))%60);
    let secs = Math.floor((diff/1000)%60);
    timerEl.textContent = days+"д "+hours+"ч "+mins+"м "+secs+"с";
  }
  setInterval(updateTimer, 1000);
  updateTimer();

  // MetaMask connect
  const connectBtn = document.getElementById('connectWalletBtn');
  if(connectBtn) {
    connectBtn.addEventListener('click', async () => {
      if(window.ethereum) {
        try {
          await ethereum.request({method:'eth_requestAccounts'});
          alert('Кошелёк подключён!');
        } catch(err) {
          alert('Ошибка подключения кошелька');
        }
      } else {
        alert('Установите MetaMask!');
      }
    });
  }

  // Uniswap link (placeholder)
  // IMPORTANT: Replace tokenAddress with your deployed token smart contract.
  // Example for ETH mainnet: https://app.uniswap.org/#/swap?outputCurrency=0xABC...
  const UNISWAP_LINK = tokenAddress
    ? `https://app.uniswap.org/#/swap?outputCurrency=${tokenAddress}`
    : 'https://app.uniswap.org/#/swap'; // generic

  const buyBtn = document.getElementById('buyTokenBtn');
  const uniBtn = document.getElementById('uniswapBtn');
  if(buyBtn) buyBtn.addEventListener('click', ()=>window.open(UNISWAP_LINK,'_blank'));
  if(uniBtn) uniBtn.addEventListener('click', ()=>window.open(UNISWAP_LINK,'_blank'));

  // Referral form
  const refForm = document.getElementById('referralForm');
  if(refForm) {
    refForm.addEventListener('submit', e => {
      e.preventDefault();
      const inp = document.getElementById('refCode');
      const code = (inp.value||'').trim();
      if(code.length < 3) {
        alert('Введите корректный реферальный код');
        return;
      }
      alert(`Реферальный код "${code}" активирован!`);
      inp.value='';
      // TODO: send to backend
    });
  }

  // Whitepaper
  const whitepaperLink = document.getElementById('whitepaperLink');
  // Replace with actual filename when ready:
  // whitepaperLink.href = 'whitepaper.pdf';
})();
